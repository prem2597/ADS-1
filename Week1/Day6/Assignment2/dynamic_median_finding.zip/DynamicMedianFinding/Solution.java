class Solution{
	public static double[] dynamicMedian(double[] arr){
		return arr;
	}
}