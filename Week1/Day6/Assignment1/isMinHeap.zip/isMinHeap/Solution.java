class Solution{
	public static boolean isMinHeap(double[] arr){
		return false;
	}
}